# ✅ Eraya Checkout System - Complete Checklist

Use this checklist to ensure everything is set up correctly.

---

## 📦 Files Verification

### Frontend Files
- [x] `sections/main-cart.liquid` - Modified with Eraya Checkout modal
- [ ] Theme uploaded to Shopify

### Backend Files
- [x] `api/create-payment.js` - Razorpay order creation endpoint
- [x] `api/verify-payment.js` - Payment verification & order creation endpoint
- [ ] Deployed to Vercel

### Configuration Files
- [x] `package.json` - Dependencies
- [x] `vercel.json` - Vercel configuration
- [x] `.env.example` - Environment variables template
- [x] `.gitignore` - Git ignore rules

### Documentation Files
- [x] `ERAYA_CHECKOUT_SETUP.md` - Complete setup guide
- [x] `README_ERAYA.md` - Project overview
- [x] `IMPLEMENTATION_SUMMARY.md` - What was built
- [x] `DEPLOY.md` - Quick deploy guide
- [x] `CHECKLIST.md` - This file

---

## 🚀 Deployment Checklist

### 1. Vercel Deployment
- [ ] Vercel CLI installed (`npm install -g vercel`)
- [ ] Logged into Vercel (`vercel login`)
- [ ] Project deployed (`vercel --prod`)
- [ ] Deployment successful (got URL: `https://shopiyf-erayastyle.vercel.app`)

### 2. Environment Variables (Vercel)
- [ ] `RAZORPAY_KEY_ID` added
- [ ] `RAZORPAY_KEY_SECRET` added
- [ ] `SHOPIFY_STORE` added (value: `www-erayastyle-com.myshopify.com`)
- [ ] `SHOPIFY_ACCESS_TOKEN` added
- [ ] Project redeployed after adding env vars

### 3. Razorpay Setup
- [ ] Razorpay account created
- [ ] Switched to **Live Mode** (not Test Mode)
- [ ] API keys generated
- [ ] Key ID copied to Vercel
- [ ] Key Secret copied to Vercel

### 4. Shopify Setup
- [ ] Custom app created in Shopify Admin
- [ ] App name: "Eraya Checkout API"
- [ ] API scopes configured:
  - [ ] `write_draft_orders`
  - [ ] `read_draft_orders`
  - [ ] `write_orders`
  - [ ] `read_orders`
  - [ ] `write_customers`
  - [ ] `read_customers`
- [ ] App installed
- [ ] Admin API access token copied to Vercel

### 5. Theme Upload
- [ ] Theme uploaded to Shopify (via CLI or ZIP)
- [ ] Theme published/activated

---

## 🧪 Testing Checklist

### Test Environment
- [ ] Razorpay in **Test Mode** for initial testing
- [ ] Made test purchase with test card
- [ ] Order created in Shopify ✅
- [ ] Switched Razorpay to **Live Mode**

### Full Payment Test
- [ ] Added product to cart
- [ ] Clicked "Checkout"
- [ ] Modal opened ✅
- [ ] Filled customer form
- [ ] Selected "Full Payment"
- [ ] Clicked "Pay ₹X"
- [ ] Razorpay popup opened ✅
- [ ] Completed payment
- [ ] Order created in Shopify ✅
- [ ] Order has tags: `eraya-checkout`, `full-payment`, `razorpay`
- [ ] Payment appears in Razorpay Dashboard ✅

### Partial Payment Test
- [ ] Added product to cart
- [ ] Clicked "Checkout"
- [ ] Modal opened ✅
- [ ] Filled customer form
- [ ] Selected "Partial Payment (30%)"
- [ ] Clicked "Pay ₹X"
- [ ] Razorpay popup opened ✅
- [ ] Completed payment (30% amount)
- [ ] Order created in Shopify ✅
- [ ] Order has tags: `eraya-checkout`, `partial-payment`, `paid-3000`, `balance-7000`
- [ ] Order note shows: "Amount Paid: ₹3,000, Balance: ₹7,000"
- [ ] Payment appears in Razorpay Dashboard ✅

### COD Test
- [ ] Added product to cart
- [ ] Clicked "Checkout"
- [ ] Modal opened ✅
- [ ] Filled customer form
- [ ] Selected "Cash on Delivery"
- [ ] Clicked "Place Order (COD)"
- [ ] Order created in Shopify ✅
- [ ] Order has tags: `eraya-checkout`, `cod-payment`, `balance-10000`
- [ ] Order note shows: "Payment Type: COD, Balance: ₹10,000"
- [ ] No payment in Razorpay Dashboard (expected)

### Mobile Testing
- [ ] Tested on mobile device
- [ ] Modal responsive ✅
- [ ] Form fields work ✅
- [ ] Payment buttons work ✅

### Error Handling
- [ ] Test with empty form → Shows validation errors ✅
- [ ] Test with invalid email → Shows error ✅
- [ ] Test payment cancellation → Modal stays open ✅
- [ ] Test API error → Shows error message ✅

---

## 🔍 Verification Checklist

### Shopify Admin
- [ ] Orders appear in **Orders** page
- [ ] Orders have correct customer info
- [ ] Orders have correct shipping address
- [ ] Orders have correct tags
- [ ] Order notes show payment details
- [ ] Order status correct (Paid/Payment Pending)

### Razorpay Dashboard
- [ ] Payments appear in **Transactions**
- [ ] Payment amounts correct
- [ ] Payment IDs match Shopify order notes
- [ ] Settlement status shows correctly

### Customer Experience
- [ ] Cart clears after checkout ✅
- [ ] Redirects to thank you page ✅
- [ ] Customer receives order confirmation email ✅

---

## 🔐 Security Checklist

- [ ] `.env` file not committed to Git
- [ ] API keys stored in Vercel environment variables only
- [ ] No sensitive data in frontend code
- [ ] Razorpay signature verification working
- [ ] HTTPS enabled (Vercel provides this)
- [ ] CORS headers configured correctly

---

## 📊 Monitoring Checklist

### Vercel
- [ ] Know how to access function logs
- [ ] Checked logs for errors
- [ ] Set up error notifications (optional)

### Razorpay
- [ ] Can view all transactions
- [ ] Can see payment details
- [ ] Know how to issue refunds

### Shopify
- [ ] Can filter orders by tag `eraya-checkout`
- [ ] Can see payment status
- [ ] Can fulfill orders

---

## 📈 Analytics Checklist (Optional)

- [ ] Track conversion rate by payment method
- [ ] Track cart abandonment rate
- [ ] Track average order value
- [ ] A/B test partial payment percentages

---

## 🎯 Go-Live Checklist

### Pre-Launch
- [ ] All tests passed ✅
- [ ] Razorpay in **Live Mode**
- [ ] Theme published on Shopify
- [ ] API deployed to Vercel
- [ ] Environment variables set
- [ ] Documentation reviewed

### Launch Day
- [ ] Monitor orders closely
- [ ] Check Razorpay for payments
- [ ] Respond to customer questions
- [ ] Watch Vercel logs for errors

### Post-Launch (First Week)
- [ ] Review all orders
- [ ] Check payment success rate
- [ ] Gather customer feedback
- [ ] Monitor conversion rates
- [ ] Fix any issues

---

## 🆘 Troubleshooting

If something doesn't work:

1. **Check Vercel function logs**
   - Vercel Dashboard → Project → Functions → View logs

2. **Check browser console**
   - F12 → Console tab → Look for errors

3. **Verify environment variables**
   - Vercel Dashboard → Settings → Environment Variables

4. **Test API endpoints manually**
   - Use Postman or curl to test `/api/create-payment`

5. **Check Razorpay mode**
   - Ensure Live Mode (not Test Mode)

6. **Check Shopify API scopes**
   - Ensure all required scopes enabled

7. **Review documentation**
   - See [ERAYA_CHECKOUT_SETUP.md](./ERAYA_CHECKOUT_SETUP.md)

---

## 📞 Support Resources

- **Setup Guide:** [ERAYA_CHECKOUT_SETUP.md](./ERAYA_CHECKOUT_SETUP.md)
- **Deploy Guide:** [DEPLOY.md](./DEPLOY.md)
- **Razorpay Docs:** https://razorpay.com/docs
- **Shopify Docs:** https://shopify.dev
- **Vercel Docs:** https://vercel.com/docs

---

## ✅ Final Sign-Off

Once everything is checked:

- [ ] **All tests passed**
- [ ] **System is live**
- [ ] **Monitoring in place**
- [ ] **Documentation complete**
- [ ] **Team trained** (if applicable)

**Congratulations! Your Eraya Checkout System is fully deployed! 🎉**

---

**System Status:** ⚠️ NOT DEPLOYED (check boxes as you complete)

**Last Updated:** 2025-10-07
