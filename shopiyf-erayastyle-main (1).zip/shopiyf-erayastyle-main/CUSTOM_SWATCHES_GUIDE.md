# 🎨 Custom Product Swatches - Usage Guide

## 🎯 What This Does

A **fully customizable color swatch system** that you control 100% from the Shopify theme editor. It works exactly like the Globo Color Swatch app but gives you complete control over design and behavior.

---

## ✅ What's Included

### 1. **Product Page Swatches** (`sections/custom-product-swatches.liquid`)
- Visual color/variant selector on product pages
- Replaces boring dropdowns with beautiful swatches
- Fully customizable design

### 2. **Product Card Swatches** (`snippets/custom-product-card-swatches.liquid`)
- Shows color options on collection pages
- Customers can see all colors before clicking
- Automatically links to variant pages

---

## 🚀 How to Use

### Step 1: Add to Product Template

1. Go to **Online Store** → **Themes** → **Customize**
2. Navigate to **Products** → **Default product**
3. Click **Add section**
4. Find **Custom Product Swatches**
5. Position it where you want (usually after product title)

### Step 2: Configure Swatch Option

1. Click on the **Custom Product Swatches** section
2. Click **Add block** → **Swatch Option**
3. Enter your option name exactly as it appears in products:
   - "Color"
   - "Material"
   - "Metal"
   - "Finish"
   etc.

### Step 3: (Optional) Add Custom Colors

If you have non-standard color names that CSS can't understand:

1. Click **Add block** → **Custom Color**
2. Enter the exact variant name (e.g., "Rose Gold")
3. Pick the hex color (e.g., #b76e79)
4. Repeat for each custom color

---

## 🎨 Customization Options

### Visual Design:
- **Swatch Shape:** Circle, Square, Rounded Square
- **Swatch Size:** Desktop & Mobile sizes
- **Border Style:** Color, width, selected state
- **Hover Effects:** Scale, lift, rotate, shadow
- **Checkmark:** Show/hide, color

### Behavior:
- **Change Variant:** Update price, availability
- **Change Image:** Update main product image
- **Tooltips:** Show color name on hover
- **Sold Out:** Show cross, grey out

### Spacing:
- Label font size & weight
- Space between swatches
- Margins & padding

---

## 📸 Adding to Collection Pages

To show swatches on product cards in collection pages:

1. Find your product card snippet (usually `snippets/product-item.liquid`)
2. Add this code where you want swatches to appear:

```liquid
{% render 'custom-product-card-swatches',
  product: product,
  swatch_size: 32,
  max_swatches: 5,
  option_name: 'Color' %}
```

### Parameters:
- `product`: The product object (required)
- `swatch_size`: Size in pixels (default: 32)
- `max_swatches`: Max to show before "+X more" (default: 5)
- `option_name`: Which option to display (default: 'Color')

---

## 🎯 Custom Color Mapping

For colors that CSS doesn't recognize:

### Your Custom Colors:
```
Rose Gold → #b76e79
Champagne Gold → #f7e7ce
Antique Silver → #c0c0c0
Midnight Blue → #191970
Brushed Steel → #8b8d8e
```

### How to Add:

1. In theme customizer, click your swatches section
2. **Add block** → **Custom Color**
3. **Color Name:** "Rose Gold" (exact match to variant)
4. **Color Value:** Pick color or enter hex
5. Save

---

## 🔄 Priority Order

The swatches use this priority:

1. **Custom Color Mapping** (what you define)
2. **Variant Images** (if available)
3. **CSS Color Names** (fallback)

Example:
```
"Rose Gold" variant
  ↓
1. Check custom colors → Found #b76e79 → Use it
2. If not found → Check variant image → Use it
3. If not found → Try CSS color "rosegold" → Use it
```

---

## 🎨 Design Examples

### Minimal Style:
```
Shape: Circle
Size: 40px
Border: 1px solid #e5e7eb
Selected: 2px solid #000
Checkmark: Hidden
Hover: Scale 1.1
```

### Bold Style:
```
Shape: Square
Size: 50px
Border: 3px solid #000
Selected: 4px solid #000 + shadow
Checkmark: White ✓
Hover: Lift up
```

### Elegant Style:
```
Shape: Rounded (8px radius)
Size: 44px
Border: 2px solid #d1d5db
Selected: 3px solid gold + glow
Checkmark: Gold ✓
Hover: Subtle scale
```

---

## 📱 Mobile Optimization

Separate settings for mobile:
- **Swatch Size Mobile:** Smaller for touch targets
- **Spacing Mobile:** Tighter layout
- **Auto-responsive:** Adjusts automatically

---

## 🆚 vs Globo Color Swatch App

### Custom Swatches (This):
✅ **100% control** over design
✅ **No monthly fees** or app limits
✅ **Faster** (no external app loading)
✅ **Customizable** from theme editor
✅ **No coding** required for customization
✅ **Works offline** (no external dependencies)

### Globo App:
✅ More features out of the box
✅ Advanced options (color picker, etc.)
❌ Monthly fee
❌ Less design control
❌ External dependency

---

## 💡 Use Cases for Your Store

### For Personalized Jewelry:

**Option 1: Metal Color**
```liquid
Swatch Option Name: "Metal"
Values: Gold, Silver, Rose Gold
```

**Option 2: Chain Length**
```liquid
Swatch Option Name: "Length"
Values: 16", 18", 20", 22"
```

**Option 3: Stone Color**
```liquid
Swatch Option Name: "Stone"
Values: Ruby, Sapphire, Emerald
```

---

## 🎯 Best Practices

### 1. **Consistent Naming**
```
✅ Good: "Gold", "Silver", "Rose Gold"
❌ Bad: "gold", "GOLD", "Gold Color"
```

### 2. **Add Variant Images**
- Upload actual product photos for each variant
- Swatches will automatically use them
- Much better than solid colors

### 3. **Limit Visible Swatches**
- Show 5-6 on product cards
- Use "+X more" for additional
- Keeps layout clean

### 4. **Test on Mobile**
- Swatches should be tappable (32px minimum)
- Not too many per row
- Good spacing

---

## 🔧 Integration with Product Pages

The swatches integrate with your theme's variant selector:

1. Click swatch → Updates variant
2. Variant changes → Updates price
3. Variant changes → Updates availability
4. Variant changes → Updates main image

All automatic! Just enable in settings.

---

## 📊 Performance

### Benefits:
✅ **Faster load** - No external app scripts
✅ **Less code** - Built into theme
✅ **No API calls** - Everything local
✅ **Better SEO** - Pure HTML/CSS

---

## 🎨 Color Examples

Common jewelry colors that work with CSS:

```
Gold → gold
Silver → silver
Black → black
White → white
Blue → blue
Red → red
Green → green
Pink → pink
```

For custom colors, add mappings:
```
Rose Gold → #b76e79
White Gold → #f5f5dc
Yellow Gold → #ffd700
Platinum → #e5e4e2
```

---

## 🚀 Quick Setup (2 Minutes)

1. **Add section** to product template
2. **Add block** → Swatch Option → Name: "Color"
3. **Customize** shape, size, colors
4. **Save** and test

That's it! Your swatches are live.

---

## 💬 Pro Tips

### Tip 1: Use Variant Images
- Best visual experience
- Shows actual product
- Automatic fallback to colors

### Tip 2: Keep It Simple
- 3-5 color options ideal
- Too many = overwhelming
- Use "+more" for extras

### Tip 3: Match Your Brand
- Use brand colors for borders
- Consistent with site design
- Professional look

### Tip 4: Test Hover States
- Make sure tooltips work
- Hover effects feel good
- Mobile tap targets work

---

## 🔄 Can Work Alongside Globo

You can use both:
- **This custom system** for products you control
- **Globo app** for complex use cases
- Enable/disable as needed

Or replace Globo entirely and save the monthly fee!

---

## 📞 Support

Need help?
- Check this guide
- Test on a duplicate theme first
- Adjust settings in theme customizer
- No coding needed for customization

---

Enjoy your custom color swatches! 🎨✨
