# 🎯 Eraya Checkout System - Setup Guide

Complete guide to set up the Eraya Custom Checkout System with Razorpay integration and Shopify order creation.

---

## 📋 What You've Built

A complete custom checkout system with **3 payment options**:

1. **Full Payment (100%)** - Pay entire amount via Razorpay
2. **Partial Payment (30%)** - Pay 30% now, 70% on delivery
3. **Cash on Delivery (0%)** - Pay full amount on delivery

---

## 🏗️ Architecture Overview

```
Customer (Browser)
    ↓
Shopify Theme (Cart Page + Modal)
    ↓
Vercel Serverless Functions
    ├── /api/create-payment.js (Creates Razorpay order)
    └── /api/verify-payment.js (Verifies payment & creates Shopify order)
    ↓
Razorpay (Payment Gateway) + Shopify (Order Management)
```

---

## 📦 Files Created

### Frontend (Shopify Theme)
- **sections/main-cart.liquid** - Modified with Eraya Checkout modal
- **sections/quick-cart.liquid** - Existing (will intercept checkout button)

### Backend (Vercel API)
- **api/create-payment.js** - Creates Razorpay payment order
- **api/verify-payment.js** - Verifies payment & creates Shopify order
- **package.json** - Dependencies for Vercel

---

## 🚀 Deployment Steps

### Step 1: Deploy Backend to Vercel

#### Option A: Using Vercel CLI (Recommended)

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Navigate to your theme directory**
   ```bash
   cd "c:\Users\ASUS\Downloads\theme export v7 (2)"
   ```

3. **Login to Vercel**
   ```bash
   vercel login
   ```

4. **Deploy to Vercel**
   ```bash
   vercel --prod
   ```

5. **Follow the prompts:**
   - Set up and deploy? **Y**
   - Which scope? Select your account
   - Link to existing project? **N**
   - Project name: **shopiyf-erayastyle**
   - Directory: **./** (current directory)
   - Override settings? **N**

6. **Your API will be live at:**
   ```
   https://shopiyf-erayastyle.vercel.app
   ```

#### Option B: Using Vercel Website

1. Go to [vercel.com](https://vercel.com)
2. Sign in with GitHub/GitLab
3. Click "Add New Project"
4. Import your repository
5. Deploy

---

### Step 2: Configure Environment Variables in Vercel

After deployment, add these environment variables in Vercel:

1. Go to your project in Vercel Dashboard
2. Click **Settings** → **Environment Variables**
3. Add the following:

#### Razorpay Credentials

```
RAZORPAY_KEY_ID=rzp_live_YOUR_KEY_ID
RAZORPAY_KEY_SECRET=YOUR_KEY_SECRET
```

**Where to get:**
- Login to [Razorpay Dashboard](https://dashboard.razorpay.com)
- Go to Settings → API Keys
- Generate keys (use **Live Mode** for production)

#### Shopify Credentials

```
SHOPIFY_STORE=www-erayastyle-com.myshopify.com
SHOPIFY_ACCESS_TOKEN=shpat_YOUR_ACCESS_TOKEN
```

**Where to get:**
- Login to Shopify Admin
- Go to **Apps** → **Develop apps** → **Create an app**
- App name: "Eraya Checkout API"
- Click **Configure Admin API scopes**
- Enable these scopes:
  - `write_draft_orders`
  - `read_draft_orders`
  - `write_orders`
  - `read_orders`
  - `write_customers`
  - `read_customers`
- Click **Install app**
- Copy the **Admin API access token** → This is your `SHOPIFY_ACCESS_TOKEN`
- Your store name is: `www-erayastyle-com.myshopify.com`

4. **Click "Save"** for each variable
5. **Redeploy** your project for changes to take effect

---

### Step 3: Upload Theme to Shopify

#### Method 1: Using Shopify CLI

```bash
# Install Shopify CLI
npm install -g @shopify/cli @shopify/theme

# Login to Shopify
shopify auth login

# Navigate to theme directory
cd "c:\Users\ASUS\Downloads\theme export v7 (2)"

# Push theme to Shopify
shopify theme push
```

#### Method 2: Manual Upload (ZIP)

1. Zip your theme folder
2. Go to Shopify Admin → **Online Store** → **Themes**
3. Click **Add theme** → **Upload ZIP file**
4. Upload the ZIP
5. Click **Publish** to make it live

---

### Step 4: Test the System

1. **Go to your store:** `www.erayastyle.com`
2. **Add a product to cart**
3. **Go to cart page or open cart drawer**
4. **Click "Checkout" button**
5. **Eraya Checkout modal should open**
6. **Fill in customer details**
7. **Select payment option:**
   - Full Payment
   - Partial Payment (30%)
   - Cash on Delivery
8. **Click "Pay ₹X" or "Place Order"**
9. **For Razorpay payments:** Complete payment in popup
10. **Order should be created in Shopify Admin**

---

## 🔍 How to Verify It's Working

### Check Vercel API Endpoints

Test your API endpoints:

**Test Create Payment:**
```bash
curl -X POST https://shopiyf-erayastyle.vercel.app/api/create-payment \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 3000,
    "paymentType": "partial",
    "customerInfo": {
      "name": "Test User",
      "email": "test@example.com",
      "phone": "+91 9876543210",
      "address": "123 Test St",
      "city": "Mumbai",
      "state": "Maharashtra",
      "pincode": "400001",
      "country": "India"
    },
    "cartItems": [],
    "cartTotal": 10000
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "razorpayOrderId": "order_XYZ123...",
  "razorpayKeyId": "rzp_live_...",
  "amount": 3000,
  "currency": "INR"
}
```

### Check Shopify Orders

1. Go to Shopify Admin → **Orders**
2. Look for orders with tags:
   - `eraya-checkout`
   - `partial-payment` or `full-payment` or `cod`
   - `paid-3000`
   - `balance-7000`
3. Check order notes for payment details

---

## 💰 Financial Breakdown Example

**Product Price: ₹10,000**

| Payment Method | Upfront | On Delivery | Razorpay Fee (2%) | You Receive |
|---------------|---------|-------------|-------------------|-------------|
| Full Payment  | ₹10,000 | ₹0          | ₹200              | ₹9,800      |
| Partial (30%) | ₹3,000  | ₹7,000      | ₹60               | ₹9,940      |
| COD           | ₹0      | ₹10,000     | ₹0                | ₹10,000     |

---

## 🎨 Customization

### Change Partial Payment Percentage

Edit `sections/main-cart.liquid`:

```liquid
<!-- Change 0.30 (30%) to 0.50 (50%) -->
<input type="radio" name="payment-method" value="partial"
       data-amount="{{ cart.total_price | times: 0.50 | round }}" checked>
```

Also update the JavaScript:
```javascript
const partialAmount = Math.round(cartTotal * 0.50); // Change to 50%
```

### Change Modal Colors

Edit the `<style>` section in `main-cart.liquid`:

```css
.eraya-submit-btn {
  background: #FF5722; /* Change button color */
}

.eraya-payment-card {
  border-color: #FF5722; /* Change border color */
}
```

### Update Vercel API URL

If you deploy to a different domain, update in `main-cart.liquid`:

```javascript
const VERCEL_API_URL = 'https://your-new-domain.vercel.app';
```

---

## 🐛 Troubleshooting

### Issue: Modal doesn't open when clicking Checkout

**Solution:**
- Check browser console for errors
- Ensure JavaScript is not blocked
- Check if cart has valid items

### Issue: Razorpay payment fails

**Solution:**
- Verify `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in Vercel
- Check Razorpay is in Live Mode (not Test Mode)
- Ensure API keys are correct

### Issue: Order not created in Shopify

**Solution:**
- Verify `SHOPIFY_STORE` and `SHOPIFY_ACCESS_TOKEN` in Vercel
- Check Shopify app has correct API scopes
- Check Vercel function logs for errors

### Issue: CORS errors in browser

**Solution:**
- Ensure API endpoints have CORS headers (already added)
- Check Vercel deployment is successful

---

## 📊 Monitoring & Logs

### Vercel Function Logs

1. Go to Vercel Dashboard
2. Click on your project
3. Go to **Functions** tab
4. Click on a function to see logs
5. Check for errors

### Razorpay Dashboard

1. Login to Razorpay Dashboard
2. Go to **Transactions**
3. See all payments
4. Check payment status, refunds, etc.

### Shopify Orders

1. Shopify Admin → **Orders**
2. Filter by tags: `eraya-checkout`
3. See all orders from Eraya Checkout

---

## 🔐 Security Notes

1. **Never commit API keys** to Git
2. **Use environment variables** for all secrets
3. **Enable Razorpay webhooks** for payment notifications
4. **Verify payment signatures** (already implemented)
5. **Use HTTPS** for all API calls (Vercel provides this)

---

## 📞 Support

### Razorpay Support
- Dashboard: https://dashboard.razorpay.com
- Docs: https://razorpay.com/docs
- Support: support@razorpay.com

### Shopify Support
- Admin: https://www.erayastyle.com/admin
- Docs: https://shopify.dev
- Support: Shopify Help Center

### Vercel Support
- Dashboard: https://vercel.com/dashboard
- Docs: https://vercel.com/docs
- Support: Vercel Community

---

## ✅ Post-Deployment Checklist

- [ ] Vercel API deployed successfully
- [ ] Environment variables configured in Vercel
- [ ] Razorpay API keys added (Live Mode)
- [ ] Shopify API credentials added
- [ ] Shopify app has correct scopes
- [ ] Theme uploaded to Shopify
- [ ] Test order placed successfully (Full Payment)
- [ ] Test order placed successfully (Partial Payment)
- [ ] Test order placed successfully (COD)
- [ ] Orders appear in Shopify Admin
- [ ] Payment appears in Razorpay Dashboard
- [ ] Customer receives order confirmation email

---

## 🎉 You're All Set!

Your Eraya Checkout System is now live! Customers can now choose between:
- **Full Payment** - Complete payment upfront
- **Partial Payment (30%)** - Lower barrier to purchase
- **Cash on Delivery** - Traditional COD

**Benefits:**
✅ Increased conversions (lower upfront cost)
✅ Reduced fake COD orders (partial payment commitment)
✅ Better cash flow (money upfront)
✅ Professional checkout experience

---

## 📈 Next Steps

1. **Monitor conversion rates** - Track how many customers use each payment option
2. **A/B test percentages** - Try 20%, 30%, 40% partial payments
3. **Add analytics** - Track which payment method converts best
4. **Customer feedback** - Ask customers about the experience
5. **Optimize** - Improve based on data and feedback

---

**Built with ❤️ for Erayastyle**

For questions or support, refer to the documentation above or check Vercel/Razorpay/Shopify docs.
