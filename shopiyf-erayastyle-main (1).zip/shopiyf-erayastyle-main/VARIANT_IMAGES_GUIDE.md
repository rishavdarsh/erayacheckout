# Variant Image Switching Guide

## Automatically Show Different Images When Customers Select Variants

Your theme has **built-in variant image switching**. When customers select a variant (like color or size), the product image automatically updates to show that specific variant.

---

## How It Works

### Automatic Image Switching

When a customer clicks a variant option:
1. ✅ Main product image changes to the variant's image
2. ✅ Image gallery updates on desktop
3. ✅ Mobile carousel slides to the variant's image
4. ✅ Thumbnail highlights the active image
5. ✅ URL updates with the selected variant

**This happens automatically** - no coding required!

---

## Setting Up Variant Images in Shopify Admin

### Step 1: Upload Product Images

1. Go to **Products** in Shopify admin
2. Open the product you want to edit
3. In the **Media** section, upload all images:
   - Different colors
   - Different angles
   - Different styles
   - Lifestyle shots

### Step 2: Assign Images to Variants

**For each variant that needs a specific image:**

1. Scroll down to the **Variants** section
2. Find the variant (e.g., "Red / Medium")
3. Click on the variant to expand it
4. In the variant's settings, find the **image** field
5. Click and select the image for that variant
6. Click **Save**

### Example: T-Shirt with 3 Colors

**Upload these images:**
- Red t-shirt front view
- Red t-shirt back view
- Blue t-shirt front view
- Blue t-shirt back view
- Black t-shirt front view
- Black t-shirt back view

**Assign images to variants:**
- Red / Small → Red t-shirt front view
- Red / Medium → Red t-shirt front view
- Red / Large → Red t-shirt front view
- Blue / Small → Blue t-shirt front view
- Blue / Medium → Blue t-shirt front view
- Blue / Large → Blue t-shirt front view
- Black / Small → Black t-shirt front view
- Black / Medium → Black t-shirt front view
- Black / Large → Black t-shirt front view

**Result:** When customer selects "Red", they see red t-shirt images. When they select "Blue", images switch to blue t-shirt.

---

## Multiple Images Per Variant (Advanced)

You can show **multiple images** for each variant using the "Enable multiple variant media" setting.

### How to Enable

1. Go to **Online Store → Themes → Customize**
2. Navigate to a **Product page**
3. Click on the main **Product information** section (not a block)
4. Scroll down to **Media grouping** settings
5. Check ✅ **"Enable multiple variant media"**
6. Click **Save**

### How It Works

When enabled:
- **Shows only images assigned to the selected variant**
- **Hides all other variant images**
- Customers see a focused gallery for each variant

### Example: Jewelry with Multiple Angles

**Product: Gold Necklace with 3 metal finishes**

**Images uploaded:**
```
1. Yellow Gold - Front view
2. Yellow Gold - Side view
3. Yellow Gold - Worn view
4. White Gold - Front view
5. White Gold - Side view
6. White Gold - Worn view
7. Rose Gold - Front view
8. Rose Gold - Side view
9. Rose Gold - Worn view
```

**Variant assignments:**
- Yellow Gold variant → Images 1, 2, 3
- White Gold variant → Images 4, 5, 6
- Rose Gold variant → Images 7, 8, 9

**Customer Experience:**
- Selects "Yellow Gold" → Sees only images 1-3
- Switches to "White Gold" → Gallery updates to show only images 4-6
- Switches to "Rose Gold" → Gallery updates to show only images 7-9

**Without this setting enabled:**
- All 9 images show regardless of selection
- Only the first image of each variant highlights when selected

---

## Image Organization Best Practices

### 1. Upload Images in Order

Upload images in the order you want them displayed:
```
✅ Good Order:
1. Main product image (default variant)
2. Alt angle of default variant
3. Lifestyle shot of default variant
4. Main image of variant 2
5. Alt angle of variant 2
6. Main image of variant 3
7. Alt angle of variant 3
```

### 2. Name Your Images Clearly

Before uploading, rename files:
```
✅ Good naming:
- red-tshirt-front.jpg
- red-tshirt-back.jpg
- blue-tshirt-front.jpg
- blue-tshirt-back.jpg

❌ Bad naming:
- IMG_1234.jpg
- IMG_1235.jpg
- IMG_1236.jpg
```

### 3. Use the First Image as the "Hero"

The first image assigned to each variant should be the best shot:
- Clear product view
- High quality
- Properly lit
- Shows the variant clearly

### 4. Be Consistent Across Variants

Use similar angles for each variant:
```
If Red variant has:
- Front view
- Back view
- Detail shot

Then Blue variant should also have:
- Front view (same angle)
- Back view (same angle)
- Detail shot (similar framing)
```

---

## Variant Swatch Images

In addition to product images, you can show **small preview images** in the variant selector (swatches).

### How to Enable Swatch Images

**Method 1: Use Variant Images (Automatic)**

1. Go to **Themes → Customize → Theme settings**
2. Navigate to **Product cards** section
3. Find **Variant swatches** settings
4. Check ✅ **"Use variant images in swatches"**
5. Click **Save**

This automatically uses the variant's featured image as the swatch.

**Method 2: Upload Custom Swatch Images**

For more control, upload swatch-specific images:

1. In your Shopify admin, go to **Content → Files**
2. Upload small square images for each variant (recommended: 100x100px)
3. Name them exactly as your variant option values:
   ```
   red.jpg
   blue.jpg
   green.jpg
   yellow.jpg
   ```
4. Make sure naming matches exactly (case-sensitive):
   - If variant is "Red" → file must be "red.jpg" or "Red.jpg"
   - If variant is "Sky Blue" → file must be "sky-blue.jpg"

### Swatch Image Tips

**Size:** 100x100px to 200x200px
**Format:** JPG or PNG
**File size:** Keep under 50KB for fast loading
**Background:**
- White background for products
- Actual texture/pattern for fabrics
- Color sample for colors

---

## Troubleshooting

### Images Not Switching When Variant Selected

**Possible causes:**

1. **No image assigned to variant**
   - Solution: Go to product admin → Variants → Select image for each variant

2. **JavaScript disabled or error**
   - Solution: Check browser console for errors
   - Try different browser

3. **Multiple variant media enabled incorrectly**
   - Solution: If images aren't grouped properly, disable this setting

### All Images Showing at Once

**Cause:** "Enable multiple variant media" is OFF (default behavior)

**Solution:**
- This is normal! All images show by default
- When variant selected, main image switches to that variant
- To hide other variant images, enable "multiple variant media" setting

### Variant Image Shows Wrong Image

**Cause:** Incorrect image assigned to variant

**Solution:**
1. Go to product in Shopify admin
2. Check each variant's image assignment
3. Re-assign correct images
4. Save product

### Swatches Not Showing Images

**Possible causes:**

1. **"Use variant images in swatches" is OFF**
   - Solution: Enable in Theme settings → Product cards

2. **Swatch file naming doesn't match**
   - Solution: Rename files to exactly match variant values

3. **Images not uploaded to Files**
   - Solution: Upload to Content → Files (not just product images)

### Mobile Carousel Not Switching

**Cause:** Mobile carousel needs to be initialized

**Solution:**
- Refresh the page
- Clear browser cache
- Check if it works on a real mobile device (not just browser resize)

---

## Advanced: Technical Details

### How the Theme Handles Variant Images

**When a variant is selected:**

1. JavaScript listens for option changes
2. Finds the selected variant's `featured_media.id`
3. Calls `switchImage()` function with that media ID
4. Updates desktop gallery, mobile carousel, and thumbnails
5. Updates URL with variant ID

**Code location:** `assets/theme.js` lines 6827-6870

**Key function:** `onOptionChange()` method in Product class

### Multiple Variant Media Logic

When enabled (`enable_multiple_variant_media: true`):

1. Theme fetches the product section via AJAX
2. Refreshes left column (images) with variant-specific media
3. Only shows images between the selected variant's featured media position and the next variant's featured media position

**Code location:** `sections/main-product--default.liquid` lines 51-73

---

## Quick Reference

### Enable Variant Image Switching
✅ **Already enabled by default** - Just assign images to variants in product admin

### Enable Multiple Images Per Variant
**Location:** Theme Customizer → Product page → Product information section → Media grouping → ✅ Enable multiple variant media

### Enable Swatch Images
**Location:** Theme Customizer → Theme settings → Product cards → ✅ Use variant images in swatches

### Assign Image to Variant
**Location:** Shopify Admin → Products → [Product] → Variants → [Click variant] → Select image → Save

---

## Examples by Product Type

### Clothing (Color Variants)
- Upload: Front, back, and detail shots for each color
- Assign: First image of each color to that color's variants
- Enable multiple variant media: **Yes** (to show only selected color)

### Jewelry (Metal Finish Variants)
- Upload: Multiple angles for each metal finish
- Assign: Hero image of each finish to that finish's variants
- Enable multiple variant media: **Yes**
- Add swatch images: Close-up of each metal texture

### Shoes (Size Variants)
- Upload: Multiple angles, all same color/style
- Assign: Same images to all size variants (since size doesn't change appearance)
- Enable multiple variant media: **No** (not needed)

### Electronics (Model Variants)
- Upload: Separate image sets for each model
- Assign: First image of each model to that model's variants
- Enable multiple variant media: **Yes**

### Cosmetics (Shade Variants)
- Upload: Swatch images and product images for each shade
- Assign: Product image to each shade variant
- Add swatch images: Color swatch files named by shade
- Enable swatch images: **Yes**

---

## Summary

✅ **Variant image switching works automatically** - just assign images to variants in Shopify admin

✅ **No coding needed** - theme handles all the JavaScript

✅ **Multiple images per variant** - enable "multiple variant media" setting

✅ **Swatch preview images** - enable "use variant images in swatches"

✅ **Mobile-friendly** - works on carousel, gallery, and thumbnails

---

Need help? Check the theme documentation at https://help.fluorescent.co/v/stiletto
