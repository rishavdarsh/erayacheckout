const crypto = require('crypto');

module.exports = async (req, res) => {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method not allowed' });
  }

  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      customerInfo,
      cartItems,
      amountPaid,
      cartTotal,
      paymentType,
      discountCode
    } = req.body;

    // Validate input
    if (!customerInfo || !cartItems || typeof amountPaid === 'undefined' || !cartTotal || !paymentType) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields'
      });
    }

    // Verify Razorpay signature if payment was made
    if (razorpay_payment_id && razorpay_order_id && razorpay_signature) {
      const body = razorpay_order_id + '|' + razorpay_payment_id;
      const expectedSignature = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
        .update(body.toString())
        .digest('hex');

      if (expectedSignature !== razorpay_signature) {
        return res.status(400).json({
          success: false,
          message: 'Invalid payment signature'
        });
      }
    }

    // Create Shopify draft order
    const shopifyOrder = await createShopifyDraftOrder({
      customerInfo,
      cartItems,
      amountPaid,
      cartTotal,
      paymentType,
      razorpay_payment_id,
      razorpay_order_id,
      discountCode
    });

    return res.status(200).json({
      success: true,
      orderNumber: shopifyOrder.name,
      orderId: shopifyOrder.id,
      orderStatusUrl: shopifyOrder.orderStatusUrl,
      message: 'Order created successfully'
    });

  } catch (error) {
    console.error('Verify payment error:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to verify payment and create order'
    });
  }
};

// Create Shopify draft order and complete it
async function createShopifyDraftOrder({
  customerInfo,
  cartItems,
  amountPaid,
  cartTotal,
  paymentType,
  razorpay_payment_id,
  razorpay_order_id,
  discountCode
}) {
  const shopifyStore = process.env.SHOPIFY_STORE;
  const shopifyAccessToken = process.env.SHOPIFY_ACCESS_TOKEN;
  const shopifyApiVersion = '2024-01';

  if (!shopifyStore || !shopifyAccessToken) {
    throw new Error('Shopify credentials not configured');
  }

  // Split customer name
  const nameParts = customerInfo.name.trim().split(' ');
  const firstName = nameParts[0] || 'Customer';
  const lastName = nameParts.slice(1).join(' ') || '';

  // Prepare line items
  const lineItems = cartItems.map(item => {
    const lineItem = {
      variant_id: item.variant_id || item.id,
      quantity: item.quantity
    };

    // Only add properties if they exist and are in correct format
    if (item.properties && typeof item.properties === 'object') {
      if (Array.isArray(item.properties)) {
        // If already an array, use it
        if (item.properties.length > 0) {
          lineItem.properties = item.properties;
        }
      } else {
        // If object, convert to array format
        const propsArray = Object.keys(item.properties).map(key => ({
          name: key,
          value: item.properties[key]
        }));
        if (propsArray.length > 0) {
          lineItem.properties = propsArray;
        }
      }
    }

    return lineItem;
  });

  // Calculate balance
  const balance = cartTotal - amountPaid;

  // Prepare order note
  let orderNote = `Eraya Checkout - ${paymentType.toUpperCase()} Payment\n\n`;
  orderNote += `Customer: ${customerInfo.name}\n`;
  orderNote += `Email: ${customerInfo.email}\n`;
  orderNote += `Phone: ${customerInfo.phone}\n\n`;
  orderNote += `Payment Details:\n`;
  orderNote += `- Payment Type: ${paymentType.toUpperCase()}\n`;
  orderNote += `- Amount Paid: ₹${amountPaid}\n`;
  orderNote += `- Balance (COD): ₹${balance}\n`;

  if (razorpay_payment_id) {
    orderNote += `- Payment ID: ${razorpay_payment_id}\n`;
    orderNote += `- Order ID: ${razorpay_order_id}\n`;
  }

  // Prepare tags
  const tags = [
    'eraya-checkout',
    `${paymentType}-payment`,
    `paid-${amountPaid}`,
    `balance-${balance}`
  ];

  if (razorpay_payment_id) {
    tags.push('razorpay');
  }

  if (discountCode) {
    tags.push(`discount-${discountCode}`);
  }

  // Create draft order
  const draftOrderPayload = {
    draft_order: {
      line_items: lineItems,
      customer: {
        first_name: firstName,
        last_name: lastName,
        email: customerInfo.email
      },
      shipping_address: {
        first_name: firstName,
        last_name: lastName,
        address1: customerInfo.address,
        phone: customerInfo.phone,
        city: customerInfo.city,
        province: customerInfo.state,
        zip: customerInfo.pincode,
        country: customerInfo.country
      },
      billing_address: {
        first_name: firstName,
        last_name: lastName,
        address1: customerInfo.address,
        phone: customerInfo.phone,
        city: customerInfo.city,
        province: customerInfo.state,
        zip: customerInfo.pincode,
        country: customerInfo.country
      },
      note: orderNote,
      tags: tags.join(', '),
      email: customerInfo.email
    }
  };

  // Add discount code if provided
  if (discountCode) {
    draftOrderPayload.draft_order.applied_discount = {
      description: `Discount code: ${discountCode}`,
      value_type: "percentage",
      value: "0",
      amount: "0",
      title: discountCode
    };
    // Note: The actual discount will be calculated by Shopify when the draft order is completed
    // We need to use price rules API or just add the code as a note
    orderNote += `\nDiscount Code Applied: ${discountCode}\n`;
    draftOrderPayload.draft_order.note = orderNote;
  }

  // Step 1: Create draft order
  const createUrl = `https://${shopifyStore}/admin/api/${shopifyApiVersion}/draft_orders.json`;
  const createResponse = await fetch(createUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': shopifyAccessToken
    },
    body: JSON.stringify(draftOrderPayload)
  });

  if (!createResponse.ok) {
    const errorText = await createResponse.text();
    console.error('Shopify draft order creation failed:', errorText);
    throw new Error(`Failed to create draft order: ${errorText}`);
  }

  const createData = await createResponse.json();
  const draftOrderId = createData.draft_order.id;

  // Step 2: Complete draft order
  const completeUrl = `https://${shopifyStore}/admin/api/${shopifyApiVersion}/draft_orders/${draftOrderId}/complete.json`;
  const completeResponse = await fetch(completeUrl, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': shopifyAccessToken
    },
    body: JSON.stringify({
      payment_pending: paymentType === 'cod' || paymentType === 'partial'
    })
  });

  if (!completeResponse.ok) {
    const errorText = await completeResponse.text();
    console.error('Shopify draft order completion failed:', errorText);
    throw new Error(`Failed to complete draft order: ${errorText}`);
  }

  const completeData = await completeResponse.json();

  // Get the actual order to retrieve the order status URL
  const orderId = completeData.draft_order.order_id;
  const orderName = completeData.draft_order.name;

  // Step 3: Create transaction for partial payment
  if (paymentType === 'partial' && amountPaid > 0 && razorpay_payment_id) {
    const transactionUrl = `https://${shopifyStore}/admin/api/${shopifyApiVersion}/orders/${orderId}/transactions.json`;
    const transactionPayload = {
      transaction: {
        kind: 'sale',
        status: 'success',
        amount: amountPaid.toFixed(2),
        currency: 'INR',
        gateway: 'Razorpay',
        source_name: 'web',
        authorization: razorpay_payment_id
      }
    };

    const transactionResponse = await fetch(transactionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': shopifyAccessToken
      },
      body: JSON.stringify(transactionPayload)
    });

    if (!transactionResponse.ok) {
      const errorText = await transactionResponse.text();
      console.error('Failed to create transaction:', errorText);
      // Don't throw error, just log it - order is already created
    } else {
      const transactionData = await transactionResponse.json();
      console.log(`Transaction created for partial payment: ₹${amountPaid}`, transactionData.transaction.id);
    }
  }

  // Fetch the order details to get confirmation URL
  const orderUrl = `https://${shopifyStore}/admin/api/${shopifyApiVersion}/orders/${orderId}.json`;
  const orderResponse = await fetch(orderUrl, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': shopifyAccessToken
    }
  });

  let confirmationUrl = null;

  if (orderResponse.ok) {
    const orderData = await orderResponse.json();
    confirmationUrl = orderData.order.order_status_url;

    // Log for debugging
    console.log('Order created:', {
      orderId: orderId,
      orderName: orderName,
      confirmationUrl: confirmationUrl,
      financialStatus: orderData.order.financial_status,
      totalPrice: orderData.order.total_price,
      currentTotalPrice: orderData.order.current_total_price
    });
  } else {
    console.error('Failed to fetch order details');
  }

  return {
    id: orderId,
    name: orderName,
    orderStatusUrl: confirmationUrl
  };
}
