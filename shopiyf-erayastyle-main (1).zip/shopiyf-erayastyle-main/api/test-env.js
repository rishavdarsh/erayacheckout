module.exports = async (req, res) => {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Check which env variables are set (without revealing values)
  const envStatus = {
    SHOPIFY_STORE: !!process.env.SHOPIFY_STORE,
    SHOPIFY_ACCESS_TOKEN: !!process.env.SHOPIFY_ACCESS_TOKEN,
    RAZORPAY_KEY_ID: !!process.env.RAZORPAY_KEY_ID,
    RAZORPAY_KEY_SECRET: !!process.env.RAZORPAY_KEY_SECRET,
    shopifyStoreValue: process.env.SHOPIFY_STORE ? process.env.SHOPIFY_STORE.substring(0, 10) + '...' : 'NOT SET',
    razorpayKeyIdValue: process.env.RAZORPAY_KEY_ID ? process.env.RAZORPAY_KEY_ID.substring(0, 8) + '...' : 'NOT SET'
  };

  return res.status(200).json({
    success: true,
    environment: envStatus,
    message: 'Environment variables check'
  });
};
