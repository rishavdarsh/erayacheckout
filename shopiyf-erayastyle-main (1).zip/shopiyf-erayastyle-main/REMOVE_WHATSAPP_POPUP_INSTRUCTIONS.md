# How to Remove WhatsApp Popup from Shopify Admin

The WhatsApp opt-in popup is being injected by a script in your Shopify admin, NOT from the theme. Follow these steps to find and remove it:

## Step 1: Check Script Tags (Most Likely Source)

1. Go to **Shopify Admin**
2. Click **Settings** (bottom left)
3. Click **Custom data** → **Metaobjects** or go directly to **Apps and sales channels** → **Develop apps**
4. Or simply go to: `https://admin.shopify.com/store/YOUR-STORE-NAME/settings/script_manager`
5. Look for any scripts related to WhatsApp or opt-in
6. **Delete** any suspicious scripts

## Step 2: Check Customer Events & Web Pixels

1. Go to **Shopify Admin** → **Settings**
2. Click **Customer events**
3. Look under **Custom pixels** for any pixel with WhatsApp code
4. Click on each pixel and check if it contains code related to "WhatsApp" or "opt-in"
5. **Remove** or **disable** the WhatsApp pixel

## Step 3: Check Checkout Scripts

1. Go to **Settings** → **Checkout**
2. Scroll down to **Order status page** section
3. Look in **Additional scripts** box
4. Check if there's any WhatsApp-related code
5. **Delete** the WhatsApp script code

## Step 4: Check Google Tag Manager

Since you have GTM installed (GTM-MTK8RTZQ):

1. Go to [Google Tag Manager](https://tagmanager.google.com/)
2. Select your container
3. Click **Tags** in the left menu
4. Look for any tag related to:
   - WhatsApp
   - Opt-in
   - Chat widget
   - Notification subscription
5. **Pause** or **Delete** the WhatsApp tag
6. Click **Submit** to publish changes

## Step 5: Check Theme Code (Already Done)

✅ We've added blocking code in your theme as a backup

## What to Look For

Search for these keywords in any scripts you find:
- `whatsapp`
- `opt-in`
- `wa-widget`
- `Welcome to Eraya`
- `Subscribe to important`
- Phone number collection
- `+91` (India country code)

## Need Help?

If you can't find where it's coming from:
1. Open your store in Chrome
2. Right-click on the popup → **Inspect**
3. Look at the HTML to find class names or script sources
4. Send me a screenshot and I can help identify the exact source

---

**Note:** The theme blocking code will hide the popup if you can't find the source, but it's better to remove the script completely from Shopify admin for better performance.
