# Quick Setup: Variant Images

## 5-Minute Setup to Show Different Images for Each Variant

---

## Basic Setup (Most Common)

### Step 1: Upload All Product Images

1. Go to **Products** in Shopify admin
2. Open your product
3. Upload ALL images:
   - All colors
   - All angles
   - All styles

### Step 2: Assign Images to Variants

1. Scroll to **Variants** section
2. Click on each variant
3. Select the image for that variant
4. Click **Save**

**Done!** Images will now switch when customers select variants.

---

## Example: T-Shirt with 3 Colors

### Images to Upload:
```
1. Red t-shirt
2. Blue t-shirt
3. Black t-shirt
```

### Variant Assignments:
```
Red / Small   → Image 1 (Red t-shirt)
Red / Medium  → Image 1 (Red t-shirt)
Red / Large   → Image 1 (Red t-shirt)

Blue / Small  → Image 2 (Blue t-shirt)
Blue / Medium → Image 2 (Blue t-shirt)
Blue / Large  → Image 2 (Blue t-shirt)

Black / Small → Image 3 (Black t-shirt)
Black / Medium→ Image 3 (Black t-shirt)
Black / Large → Image 3 (Black t-shirt)
```

### Result:
- Customer clicks "Red" → Shows red t-shirt
- Customer clicks "Blue" → Shows blue t-shirt
- Customer clicks "Black" → Shows black t-shirt

---

## Advanced Setup: Multiple Images Per Variant

**Use this when:** Each variant has multiple photos (front, back, detail, etc.)

### Step 1: Upload Images in Groups

```
Images 1-3: Red variant (front, back, detail)
Images 4-6: Blue variant (front, back, detail)
Images 7-9: Black variant (front, back, detail)
```

### Step 2: Assign FIRST Image of Each Group

```
Red variants → Image 1
Blue variants → Image 4
Black variants → Image 7
```

### Step 3: Enable Multiple Variant Media

1. Go to **Themes → Customize**
2. Open a **Product page**
3. Click on **Product information** section
4. Scroll to **Media grouping**
5. Check ✅ **"Enable multiple variant media"**
6. Click **Save**

### Result:
- Customer selects "Red" → Shows ONLY images 1-3
- Customer selects "Blue" → Shows ONLY images 4-6
- Customer selects "Black" → Shows ONLY images 7-9

---

## Checklist

### Basic Variant Images (Works Right Away)
- [ ] Upload all product images to product in Shopify admin
- [ ] Open each variant and assign its image
- [ ] Save the product
- [ ] Test on storefront: Select variant and check if image changes

### Multiple Images Per Variant (Optional)
- [ ] Upload images in groups (all Red images, then all Blue images, etc.)
- [ ] Assign the first image of each group to that variant
- [ ] Enable "Multiple variant media" in theme customizer
- [ ] Save and test

### Color Swatches with Images (Optional)
- [ ] Go to **Themes → Customize → Theme settings**
- [ ] Navigate to **Product cards** section
- [ ] Check ✅ **"Use variant images in swatches"**
- [ ] Save

---

## Visual Guide

### Before Setup:
```
Customer selects "Blue" → Still shows red product image ❌
```

### After Setup:
```
Customer selects "Blue" → Automatically shows blue product image ✅
```

---

## Common Questions

### Q: Do I need to assign images to every variant?
**A:** Only to variants where the product looks different. For example:
- **Color variants** → Yes, assign different images
- **Size variants** → No, they look the same

### Q: Can I use the same image for multiple variants?
**A:** Yes! For example, all size variants of "Red / Small", "Red / Medium", "Red / Large" can use the same red product image.

### Q: How many images can I upload per product?
**A:** Shopify allows up to 250 images per product.

### Q: Will this work on mobile?
**A:** Yes! The theme automatically updates mobile carousel when variant is selected.

---

## Pro Tips

### 1. Upload Images in Order
Upload all Red images first, then Blue images, then Black images. This keeps your media library organized.

### 2. Name Files Before Uploading
Rename files before uploading:
```
red-front.jpg
red-back.jpg
blue-front.jpg
blue-back.jpg
```

### 3. Use Consistent Angles
If Red has front + back + detail views, make sure Blue and Black also have the same views.

### 4. Set the Best Image as Variant Image
Assign the clearest, best-lit image as the variant's featured image.

---

## Troubleshooting

### Images not switching?
1. Check if image is assigned to variant in product admin
2. Refresh the page and clear cache
3. Check browser console for errors

### All images showing instead of just variant images?
This is normal! To show only variant-specific images, enable "Multiple variant media" setting.

### Wrong image showing for variant?
Go back to product admin and double-check which image is assigned to that variant.

---

## Complete Setup Time

- **Basic setup:** 2-5 minutes per product
- **Advanced setup:** 5-10 minutes per product
- **One-time theme settings:** 1 minute

---

## Next Steps

1. ✅ Set up variant images on your best-selling products first
2. ✅ Test the customer experience on both desktop and mobile
3. ✅ Enable swatch images for visual variant selection
4. ✅ Roll out to all products with variants

---

**That's it!** Your products now show the correct image for each variant automatically.

For detailed information, see [VARIANT_IMAGES_GUIDE.md](VARIANT_IMAGES_GUIDE.md)
