# 🚀 Quick Deploy Guide

**Get your Eraya Checkout System live in 15 minutes!**

---

## Step 1: Deploy Backend (5 minutes)

### Option A: Using Vercel CLI

Open terminal in this directory and run:

```bash
# Install Vercel CLI (if not already installed)
npm install -g vercel

# Login to Vercel
vercel login

# Deploy
vercel --prod
```

**Your API will be at:** `https://shopiyf-erayastyle.vercel.app`

### Option B: Using Vercel Website

1. Go to [vercel.com](https://vercel.com)
2. Sign in
3. Click "Add New Project"
4. Import this repository
5. Click "Deploy"

---

## Step 2: Add Environment Variables (10 minutes)

Go to your Vercel project → Settings → Environment Variables

Add these 4 variables:

### 1. Razorpay Key ID
```
RAZORPAY_KEY_ID=rzp_live_YOUR_KEY_HERE
```
**Get it:** [Razorpay Dashboard](https://dashboard.razorpay.com) → Settings → API Keys

### 2. Razorpay Key Secret
```
RAZORPAY_KEY_SECRET=YOUR_SECRET_HERE
```
**Get it:** Same page as above

### 3. Shopify Store
```
SHOPIFY_STORE=www-erayastyle-com.myshopify.com
```
**Already set** (your store name)

### 4. Shopify Access Token
```
SHOPIFY_ACCESS_TOKEN=shpat_YOUR_TOKEN_HERE
```
**Get it:**
1. Shopify Admin → Apps → Develop apps
2. Create app: "Eraya Checkout"
3. Configure Admin API scopes:
   - `write_draft_orders`
   - `read_draft_orders`
   - `write_orders`
   - `read_orders`
   - `write_customers`
   - `read_customers`
4. Install app
5. Copy "Admin API access token"

**After adding all 4, click "Redeploy" in Vercel**

---

## Step 3: Upload Theme (5 minutes)

### Option A: Shopify CLI

```bash
# Install Shopify CLI
npm install -g @shopify/cli @shopify/theme

# Login
shopify auth login

# Push theme
shopify theme push
```

### Option B: Manual Upload

1. Zip this folder
2. Shopify Admin → Online Store → Themes
3. Add theme → Upload ZIP
4. Publish

---

## Step 4: Test (5 minutes)

1. Go to your store: `www.erayastyle.com`
2. Add product to cart
3. Click "Checkout"
4. Modal should open
5. Test all 3 payment options:
   - ✅ Full Payment
   - ✅ Partial Payment (30%)
   - ✅ Cash on Delivery
6. Check Shopify Admin for orders
7. Check Razorpay Dashboard for payments

---

## ✅ Done!

Your Eraya Checkout System is now **LIVE**! 🎉

---

## 🆘 Troubleshooting

### Modal doesn't open
- Check browser console for errors
- Ensure theme uploaded correctly

### Payment fails
- Check Razorpay keys are correct
- Ensure Razorpay is in **Live Mode** (not Test Mode)

### Order not created
- Check Shopify access token is correct
- Check API scopes are enabled
- Check Vercel function logs

---

## 📞 Need Help?

See [ERAYA_CHECKOUT_SETUP.md](./ERAYA_CHECKOUT_SETUP.md) for detailed troubleshooting.

---

**Total Time:** ~25 minutes
**Difficulty:** Easy ⭐⭐

Go live now! 🚀
