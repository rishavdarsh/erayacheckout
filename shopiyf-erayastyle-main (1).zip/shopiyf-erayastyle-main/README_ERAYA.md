# 🛍️ Eraya Custom Checkout System

A complete custom checkout solution for Shopify with **3 flexible payment options**: Full Payment, Partial Payment (30%), and Cash on Delivery.

## 🌟 Features

✅ **Full Payment** - Complete payment via Razorpay
✅ **Partial Payment (30%)** - Pay 30% now, 70% on delivery
✅ **Cash on Delivery** - Traditional COD option
✅ **Seamless Integration** - Works with existing Shopify theme
✅ **Secure Payments** - Razorpay integration with signature verification
✅ **Auto Order Creation** - Orders created in Shopify Admin automatically
✅ **Mobile Responsive** - Works on all devices

## 📁 Project Structure

```
theme/
├── sections/
│   └── main-cart.liquid          # Cart page with Eraya Checkout modal
├── api/
│   ├── create-payment.js         # Razorpay order creation
│   └── verify-payment.js         # Payment verification & Shopify order creation
├── package.json                  # Dependencies
├── vercel.json                   # Vercel configuration
├── .env.example                  # Environment variables template
├── ERAYA_CHECKOUT_SETUP.md       # Complete setup guide
└── README_ERAYA.md               # This file
```

## 🚀 Quick Start

### 1. Deploy to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

### 2. Configure Environment Variables

In Vercel Dashboard, add:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `SHOPIFY_STORE`
- `SHOPIFY_ACCESS_TOKEN`

### 3. Upload Theme to Shopify

```bash
shopify theme push
```

## 📖 Documentation

See [ERAYA_CHECKOUT_SETUP.md](./ERAYA_CHECKOUT_SETUP.md) for complete setup instructions.

## 🎯 How It Works

1. Customer clicks **Checkout** on cart/drawer
2. **Eraya Checkout Modal** opens with customer form
3. Customer selects payment option:
   - Full Payment → Pay 100% via Razorpay
   - Partial Payment → Pay 30% via Razorpay, 70% COD
   - COD → Pay 100% on delivery
4. Payment processed (if Razorpay)
5. **Order created in Shopify** with tags and notes
6. Customer redirected to thank you page

## 💡 Example Flow

**Product: ₹10,000 Necklace**

**Partial Payment Selected:**
- Customer pays: **₹3,000** (30%)
- Razorpay fee: **₹60** (2%)
- You receive: **₹2,940**
- Balance COD: **₹7,000**
- Total received: **₹9,940**

## 🔐 Security

- ✅ API keys stored in environment variables
- ✅ Razorpay signature verification
- ✅ CORS protection
- ✅ HTTPS only (via Vercel)

## 📊 Tech Stack

- **Frontend:** Liquid (Shopify Theme)
- **Backend:** Node.js (Vercel Serverless)
- **Payment:** Razorpay
- **Orders:** Shopify Admin API
- **Hosting:** Vercel

## 🛠️ API Endpoints

### POST /api/create-payment
Creates a Razorpay payment order

**Request:**
```json
{
  "amount": 3000,
  "paymentType": "partial",
  "customerInfo": { ... },
  "cartItems": [ ... ],
  "cartTotal": 10000
}
```

**Response:**
```json
{
  "success": true,
  "razorpayOrderId": "order_...",
  "razorpayKeyId": "rzp_live_...",
  "amount": 3000
}
```

### POST /api/verify-payment
Verifies payment and creates Shopify order

**Request:**
```json
{
  "razorpay_order_id": "order_...",
  "razorpay_payment_id": "pay_...",
  "razorpay_signature": "...",
  "customerInfo": { ... },
  "cartItems": [ ... ],
  "amountPaid": 3000,
  "cartTotal": 10000,
  "paymentType": "partial"
}
```

**Response:**
```json
{
  "success": true,
  "orderNumber": "#1001",
  "orderId": 54321
}
```

## 📞 Support

- **Setup Guide:** [ERAYA_CHECKOUT_SETUP.md](./ERAYA_CHECKOUT_SETUP.md)
- **Razorpay Docs:** https://razorpay.com/docs
- **Shopify API Docs:** https://shopify.dev
- **Vercel Docs:** https://vercel.com/docs

## 📝 License

MIT

---

**Made with ❤️ for Erayastyle**
